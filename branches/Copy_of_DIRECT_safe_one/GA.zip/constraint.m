function [gineq,geq] = constraint(x)
    
gineq = [];
geq = [];

%set inequality constraints
gineq(1)=-3*x(1)-6*x(2)-11*x(3)-x(4)+5;
gineq(2)=-12*x(1)-12*x(2)+42*x(3)-52*x(4)+21+5*(0.3*x(1)^2+0.2*x(2)^2+21*x(3)^2)^(1/2);

%set equality constraints
%Note that GA in matlab cannot use equality constraints!
%You should convert a equlity constraint to two inequality constraints
%For example, x(1)+x(2)=1 --> x(1)+x(2)-1<=0 and x(1)+x(2)-1>=0

gineq(3)=x(1)+x(2)+x(3)+x(4)-1;
gineq(4)=-x(1)-x(2)-x(3)-x(4)+1;