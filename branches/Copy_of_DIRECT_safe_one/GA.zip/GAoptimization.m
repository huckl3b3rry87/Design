%%%%%%%%%%%%%% ME555W15 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%% Genetic Algorithm Templet %%%%%%%%%%%%%%%%%%%%%%%

%% Optional overhead
clear; % Clear the workspace
close all; % Close all windows

%% Optimization settings

% set number of design variables
nvars=4; % x1, x2, x3, x4 

% Set lower bound and upper bound
lb=[-10 -10 -10 -10]; %lower bounds of x1 and x2
ub=[10 10 10 10]; %upper bounds of x1 and x2

% Set integer variables
IntCon=[1,4]; % x1 and x4 are integer. 

% Set the initial guess (Optional) - set the vectors of population size. 
% If you use 100 populations and 4 design variables, 
% initial guess will be 100 x 4 matrix
ini=rand(100,4); % Please use GOOD and FEASIBLE initial guess if possible.

% Set objective function
vfun=@(x)objective(x);
% Set constraint function
nonlcon=@(x)constraint(x);

%% GA option settings
populations=100; %set population size
generations=30; %set number of generations

% @gaplotbestfun will show you a convergence plot. Based on this, tune population size and number of generations 
options = gaoptimset('InitialPopulation',ini,'PopulationSize',populations,'Generations',generations,'PlotFcns',@gaplotbestfun);

%% Solve problem 
[x,fval,exitflag,output] = ga(vfun,nvars,[],[],[],[],lb,ub,nonlcon,IntCon,options)

